import Movie from './Movie'

export const API = {
    Movie
}
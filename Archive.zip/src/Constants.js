export const TIMER = {
    'DEBOUNCE': 1000
}